ALX - Python Inheritance
