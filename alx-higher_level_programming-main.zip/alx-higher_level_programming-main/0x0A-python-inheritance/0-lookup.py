#!/usr/bin/python3
"""defining the function lookup"""


def lookup(obj):
    """returns list object"""
    return dir(obj)
