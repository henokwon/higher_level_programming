#!/usr/bin/python3
"""creating BaseGeometry class"""


class BaseGeometry:
    """empty class"""
    pass
