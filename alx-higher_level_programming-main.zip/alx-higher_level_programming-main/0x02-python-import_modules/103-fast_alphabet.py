#!/usr/bin/python3
import fast_alphabet_103
