#!/usr/bin/python3
b = 98
"""Simple variable
"""
