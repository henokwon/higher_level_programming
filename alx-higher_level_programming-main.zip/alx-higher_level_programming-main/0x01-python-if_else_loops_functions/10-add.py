#!/usr/bin/python3


def add(a, b):
    return (a + b)
