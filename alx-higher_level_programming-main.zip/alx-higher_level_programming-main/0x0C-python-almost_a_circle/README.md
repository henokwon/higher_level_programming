ALX - python-almost a circle
