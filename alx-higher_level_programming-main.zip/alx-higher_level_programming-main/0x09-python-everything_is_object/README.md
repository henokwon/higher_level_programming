ALX - Python everything is object
