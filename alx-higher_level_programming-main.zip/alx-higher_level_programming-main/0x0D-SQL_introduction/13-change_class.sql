-- Script that remove all scores minor than  5 --
DELETE FROM second_table WHERE (score <= 5);
