-- finding the score in the second table --
SELECT AVG(score) as average FROM second_table;
