-- add new row
-- add new row
INSERT INTO first_table (id,name) VALUES (89,'Best School');
