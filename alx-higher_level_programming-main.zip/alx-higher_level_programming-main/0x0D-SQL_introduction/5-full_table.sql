-- Script that prints the full description of first_table from hbtn_0c_0
SHOW CREATE TABLE first_table;
