-- create table
-- create table id int
CREATE TABLE IF NOT EXISTS first_table (
    id INT,
    name VARCHAR(256)
);
