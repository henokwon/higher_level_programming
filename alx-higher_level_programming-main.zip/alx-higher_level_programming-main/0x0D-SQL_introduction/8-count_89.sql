-- Script that displays the number of records with id = 89 in first_table of hbtn_0c_0
SELECT COUNT(*) FROM first_table WHERE id=89;
