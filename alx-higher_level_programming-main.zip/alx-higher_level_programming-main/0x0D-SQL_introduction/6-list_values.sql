-- Script that lists all rows of first_table from hbtn_0c_0 in your MySQL server
SELECT * FROM first_table;
