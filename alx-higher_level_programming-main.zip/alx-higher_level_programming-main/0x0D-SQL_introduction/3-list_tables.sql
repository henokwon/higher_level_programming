-- Script that lists all the tables of a database in your MySQL server
SHOW TABLES;
