#!/usr/bin/node
module.exports = class Rectangle {

};
