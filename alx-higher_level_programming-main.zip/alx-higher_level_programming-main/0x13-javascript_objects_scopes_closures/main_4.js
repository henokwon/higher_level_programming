#!/usr/bin/node
const Rectangle = require('./4-rectangle');

const r1 = new Rectangle(1, 2);
r1.print();
r1.rotate();
r1.print();
r1.double();
r1.print();
