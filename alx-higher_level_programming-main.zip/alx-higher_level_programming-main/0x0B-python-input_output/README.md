ALX - Python Input Output
