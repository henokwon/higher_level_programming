ALX project - python exceptions
