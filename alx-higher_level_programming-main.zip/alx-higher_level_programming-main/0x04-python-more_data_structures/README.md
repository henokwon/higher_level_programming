ALX - More data structures
